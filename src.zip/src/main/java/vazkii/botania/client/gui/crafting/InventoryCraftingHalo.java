/**
 * This class was created by <Vazkii>. It's distributed as
 * part of the Botania Mod. Get the Source Code in github:
 * https://github.com/Vazkii/Botania
 * 
 * Botania is Open Source and distributed under the
 * Botania License: http://botaniamod.net/license.php
 * 
 * File Created @ [Dec 20, 2014, 4:29:09 PM (GMT)]
 */
package vazkii.botania.client.gui.crafting;

import net.minecraft.inventory.Container;
import net.minecraft.inventory.InventoryCrafting;

public class InventoryCraftingHalo extends InventoryCrafting {

	public InventoryCraftingHalo(Container p_i1807_1_, int p_i1807_2_, int p_i1807_3_) {
		super(p_i1807_1_, p_i1807_2_, p_i1807_3_);
	}

}
