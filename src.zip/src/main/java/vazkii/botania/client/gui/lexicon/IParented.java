package vazkii.botania.client.gui.lexicon;

public interface IParented {

	public void setParent(GuiLexicon gui);

}
